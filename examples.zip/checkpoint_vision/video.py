from __future__ import annotations

import time
from dataclasses import dataclass

import cv2
import numpy as np


@dataclass
class FramePacket:
    frame: np.ndarray
    timestamp: float
    fps: float


class FrameSource:
    """File or RTSP source with reconnects for network streams."""

    def __init__(self, source: str, reconnect_delay: float = 3.0, resize_width: int | None = None):
        self.source = source
        self.reconnect_delay = reconnect_delay
        self.resize_width = resize_width
        self.is_network = source.lower().startswith(("rtsp://", "rtsps://", "http://", "https://"))
        self.capture: cv2.VideoCapture | None = None
        self._time_origin = time.monotonic()
        self._open()

    def _open(self) -> None:
        self.release()
        self.capture = cv2.VideoCapture(self.source)
        if not self.capture.isOpened():
            self.release()
            raise RuntimeError(f"Cannot open video source: {self.source}")

    def read(self) -> FramePacket | None:
        if self.capture is None:
            return None
        ok, frame = self.capture.read()
        if not ok:
            if not self.is_network:
                return None
            self.release()
            time.sleep(self.reconnect_delay)
            try:
                self._open()
            except RuntimeError:
                return None
            return None
        if self.resize_width and frame.shape[1] != self.resize_width:
            ratio = self.resize_width / frame.shape[1]
            frame = cv2.resize(frame, (self.resize_width, round(frame.shape[0] * ratio)))
        fps = float(self.capture.get(cv2.CAP_PROP_FPS) or 0.0)
        if fps < 1 or fps > 240:
            fps = 25.0
        if self.is_network:
            # Keep time continuous through RTSP reconnects, so tracker ages and
            # event clips do not move backwards after an outage.
            timestamp = time.monotonic() - self._time_origin
        else:
            timestamp = float(self.capture.get(cv2.CAP_PROP_POS_MSEC)) / 1000.0
            if timestamp <= 0:
                timestamp = float(self.capture.get(cv2.CAP_PROP_POS_FRAMES)) / fps
        return FramePacket(frame=frame, timestamp=timestamp, fps=fps)

    def release(self) -> None:
        if self.capture is not None:
            self.capture.release()
        self.capture = None
