from __future__ import annotations

import argparse
import sys

import cv2
import numpy as np

from checkpoint_vision.background import AdaptiveBackground, detections_from_mask
from checkpoint_vision.calibration import calibrate_background, calibrate_roi, roi_mask
from checkpoint_vision.config import AppConfig, ensure_runtime_ready, load_config
from checkpoint_vision.events import EventRecorder, FrameBuffer
from checkpoint_vision.tracker import StationaryTracker
from checkpoint_vision.verifier import AcceptAllVerifier
from checkpoint_vision.video import FrameSource


def _load_background(config: AppConfig) -> np.ndarray:
    image = cv2.imread(str(config.background_path), cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError(f"Cannot read background: {config.background_path}")
    return image


def _draw(frame: np.ndarray, polygon: list[list[int]], tracker: StationaryTracker, now: float) -> np.ndarray:
    result = frame.copy()
    cv2.polylines(result, [np.asarray(polygon, dtype=np.int32)], True, (255, 255, 0), 2)
    for candidate in tracker.candidates:
        x, y, width, height = candidate.bbox
        color = (0, 0, 255) if candidate.alerted else (0, 220, 255)
        cv2.rectangle(result, (x, y), (x + width, y + height), color, 2)
        label = f"#{candidate.id} {candidate.age(now):.1f}s" + (" ALERT" if candidate.alerted else "")
        cv2.putText(result, label, (x, max(20, y - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2)
    return result


def run(config: AppConfig, source_override: str | None = None, display: bool = True) -> None:
    if source_override:
        config.source = source_override
    ensure_runtime_ready(config)
    background = _load_background(config)
    model = AdaptiveBackground(background, config.background)
    tracker = StationaryTracker(config.detection)
    verifier = AcceptAllVerifier()
    recorder = EventRecorder(config.events_path, config.events)
    buffer = FrameBuffer(config.events.pre_seconds)
    source = FrameSource(config.resolved_source, config.runtime.reconnect_delay_seconds, config.runtime.resize_width)
    mask: np.ndarray | None = None
    roi: np.ndarray | None = None
    print("Analysis started. Press q/Esc to quit; r to reset candidates.")
    try:
        while True:
            packet = source.read()
            if packet is None:
                if source.is_network:
                    continue
                break
            frame, now = packet.frame, packet.timestamp
            if roi is None:
                roi = roi_mask(frame.shape, config.roi.points)
            mask = model.foreground(frame, roi, config.detection)
            detections = detections_from_mask(mask, config.detection)
            alerts = tracker.update(detections, now)
            for candidate in alerts:
                if not verifier.verify(frame, candidate.bbox):
                    continue
                metadata = {
                    "event_type": "stationary_foreground_candidate",
                    "timestamp_seconds": now,
                    "candidate_id": candidate.id,
                    "bbox_xywh": list(candidate.bbox),
                    "age_seconds": candidate.age(now),
                    "source": config.source,
                }
                directory = recorder.start(now, frame, packet.fps, metadata, buffer.snapshot())
                print(f"ALERT: candidate #{candidate.id}; event saved to {directory}")
            recorder.write_frame(now, frame)
            buffer.add(now, frame)
            if display:
                cv2.imshow("Checkpoint Vision", _draw(frame, config.roi.points, tracker, now))
                cv2.imshow("Foreground mask", mask)
                key = cv2.waitKey(1) & 0xFF
                if key in (27, ord("q")):
                    break
                if key == ord("r"):
                    tracker.reset()
                    print("Candidates reset.")
    finally:
        source.release()
        recorder.close()
        if display:
            cv2.destroyAllWindows()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Detect persistent foreground objects in a fixed camera view.")
    subcommands = parser.add_subparsers(dest="command", required=True)
    for name in ("calibrate-roi", "calibrate-background", "run"):
        command = subcommands.add_parser(name)
        command.add_argument("--config", required=True, help="Path to YAML configuration")
        command.add_argument("--source", help="Override source from configuration")
        if name == "run":
            command.add_argument("--no-display", action="store_true", help="Disable OpenCV windows")
    return parser


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    try:
        config = load_config(args.config)
        if args.source:
            config.source = args.source
        if args.command == "calibrate-roi":
            calibrate_roi(config, args.source)
        elif args.command == "calibrate-background":
            calibrate_background(config, args.source)
        elif args.command == "run":
            run(config, args.source, not args.no_display)
    except (FileNotFoundError, ValueError, RuntimeError) as error:
        print(f"Error: {error}", file=sys.stderr)
        raise SystemExit(2) from error


if __name__ == "__main__":
    main()
