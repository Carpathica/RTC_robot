from __future__ import annotations

import json
from collections import deque
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any
from uuid import uuid4

import cv2
import numpy as np

from checkpoint_vision.config import EventConfig


class FrameBuffer:
    def __init__(self, seconds: float):
        self.seconds = seconds
        self.frames: deque[tuple[float, np.ndarray]] = deque()

    def add(self, timestamp: float, frame: np.ndarray) -> None:
        self.frames.append((timestamp, frame.copy()))
        while self.frames and timestamp - self.frames[0][0] > self.seconds:
            self.frames.popleft()

    def snapshot(self) -> list[tuple[float, np.ndarray]]:
        return list(self.frames)


@dataclass
class _ActiveRecording:
    writer: cv2.VideoWriter
    end_time: float


class EventRecorder:
    def __init__(self, root: Path, config: EventConfig):
        self.root = root
        self.config = config
        self.active: list[_ActiveRecording] = []
        self.root.mkdir(parents=True, exist_ok=True)

    def start(self, timestamp: float, frame: np.ndarray, fps: float, metadata: dict[str, Any], pre_frames: list[tuple[float, np.ndarray]]) -> Path:
        event_id = f"{datetime.now():%Y%m%d_%H%M%S}_{uuid4().hex[:8]}"
        directory = self.root / event_id
        directory.mkdir(parents=True, exist_ok=False)
        with (directory / "event.json").open("w", encoding="utf-8") as handle:
            json.dump(metadata, handle, ensure_ascii=False, indent=2)
        cv2.imwrite(str(directory / "alert.jpg"), frame)
        height, width = frame.shape[:2]
        writer = cv2.VideoWriter(str(directory / "clip.mp4"), cv2.VideoWriter_fourcc(*self.config.codec), max(fps, 1.0), (width, height))
        if not writer.isOpened():
            raise RuntimeError("Could not create event video writer. Check OpenCV codecs.")
        for _, buffered in pre_frames:
            writer.write(buffered)
        self.active.append(_ActiveRecording(writer, timestamp + self.config.post_seconds))
        return directory

    def write_frame(self, timestamp: float, frame: np.ndarray) -> None:
        for recording in self.active[:]:
            recording.writer.write(frame)
            if timestamp >= recording.end_time:
                recording.writer.release()
                self.active.remove(recording)

    def close(self) -> None:
        for recording in self.active:
            recording.writer.release()
        self.active.clear()
