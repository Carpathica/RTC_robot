from __future__ import annotations

import time
from pathlib import Path

import cv2
import numpy as np

from checkpoint_vision.config import AppConfig, save_config
from checkpoint_vision.video import FrameSource


def roi_mask(shape: tuple[int, int] | tuple[int, int, int], points: list[list[int]]) -> np.ndarray:
    mask = np.zeros(shape[:2], dtype=np.uint8)
    if len(points) >= 3:
        cv2.fillPoly(mask, [np.asarray(points, dtype=np.int32)], 255)
    return mask


def select_clean_frames(
    frames: list[np.ndarray], mask: np.ndarray, motion_threshold: int, max_motion_fraction: float
) -> list[np.ndarray]:
    """Keep frames whose change from the preceding frame is small inside ROI."""
    if not frames:
        return []
    selected = [frames[0]]
    previous = cv2.cvtColor(frames[0], cv2.COLOR_BGR2GRAY)
    roi_pixels = max(1, cv2.countNonZero(mask))
    for frame in frames[1:]:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        difference = cv2.absdiff(gray, previous)
        _, moving = cv2.threshold(difference, motion_threshold, 255, cv2.THRESH_BINARY)
        moving = cv2.bitwise_and(moving, mask)
        if cv2.countNonZero(moving) / roi_pixels <= max_motion_fraction:
            selected.append(frame)
        previous = gray
    return selected


def median_background(frames: list[np.ndarray]) -> np.ndarray:
    if not frames:
        raise ValueError("No clean frames were captured.")
    return np.median(np.stack(frames, axis=0), axis=0).astype(np.uint8)


def calibrate_roi(config: AppConfig, source_override: str | None = None) -> None:
    source_value = source_override or config.resolved_source
    source = FrameSource(source_value, config.runtime.reconnect_delay_seconds, config.runtime.resize_width)
    try:
        packet = source.read()
        if packet is None:
            raise RuntimeError("No frame was received from source.")
        frame = packet.frame
    finally:
        source.release()

    points: list[list[int]] = []
    window = "ROI calibration"

    def redraw() -> np.ndarray:
        image = frame.copy()
        if points:
            cv2.polylines(image, [np.asarray(points, dtype=np.int32)], len(points) >= 3, (0, 255, 255), 2)
            for point in points:
                cv2.circle(image, tuple(point), 4, (0, 255, 255), -1)
        cv2.putText(image, "LMB:add  RMB:undo  ENTER:save  ESC:cancel", (12, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
        return image

    def on_mouse(event: int, x: int, y: int, _flags: int, _param: object) -> None:
        if event == cv2.EVENT_LBUTTONDOWN:
            points.append([x, y])
        elif event == cv2.EVENT_RBUTTONDOWN and points:
            points.pop()

    cv2.namedWindow(window, cv2.WINDOW_NORMAL)
    cv2.setMouseCallback(window, on_mouse)
    while True:
        cv2.imshow(window, redraw())
        key = cv2.waitKey(20) & 0xFF
        if key in (13, 10):
            if len(points) < 3:
                print("At least three points are required.")
                continue
            config.roi.points = points
            save_config(config)
            print(f"ROI saved to {config.config_path}")
            break
        if key in (27, ord("q")):
            print("ROI calibration cancelled.")
            break
    cv2.destroyWindow(window)


def calibrate_background(config: AppConfig, source_override: str | None = None) -> Path:
    if len(config.roi.points) < 3:
        raise ValueError("ROI is not configured. Run calibrate-roi first.")
    source_value = source_override or config.resolved_source
    source = FrameSource(source_value, config.runtime.reconnect_delay_seconds, config.runtime.resize_width)
    try:
        collected: list[np.ndarray] = []
        started = time.monotonic()
        mask: np.ndarray | None = None
        latest: np.ndarray | None = None
        while time.monotonic() - started < config.background.calibration_seconds:
            packet = source.read()
            if packet is None:
                continue
            latest = packet.frame
            if mask is None:
                mask = roi_mask(latest.shape, config.roi.points)
            collected.append(latest.copy())
            preview = latest.copy()
            elapsed = time.monotonic() - started
            cv2.putText(preview, f"Collecting: {elapsed:.0f}/{config.background.calibration_seconds}s", (12, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
            cv2.imshow("Background calibration", preview)
            if cv2.waitKey(1) & 0xFF in (27, ord("q")):
                raise RuntimeError("Background calibration cancelled.")
    finally:
        source.release()
        cv2.destroyWindow("Background calibration")
    if mask is None or latest is None:
        raise RuntimeError("No frames were received during calibration.")
    clean = select_clean_frames(collected, mask, config.background.motion_threshold, config.background.max_motion_fraction)
    if len(clean) < config.background.min_clean_frames:
        raise RuntimeError(
            f"Only {len(clean)} clean frames were accepted; at least "
            f"{config.background.min_clean_frames} are required. Clear the ROI and retry."
        )
    background = median_background(clean)
    target = config.background_path
    target.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(target), background):
        raise RuntimeError(f"Unable to write background image: {target}")
    print(f"Saved background from {len(clean)} clean frames to {target}")
    return target
