from __future__ import annotations

from dataclasses import dataclass

from checkpoint_vision.background import Detection
from checkpoint_vision.config import DetectionConfig


def _center(box: tuple[int, int, int, int]) -> tuple[float, float]:
    x, y, width, height = box
    return x + width / 2, y + height / 2


def _distance(left: tuple[int, int, int, int], right: tuple[int, int, int, int]) -> float:
    lx, ly = _center(left)
    rx, ry = _center(right)
    return ((lx - rx) ** 2 + (ly - ry) ** 2) ** 0.5


def _iou(left: tuple[int, int, int, int], right: tuple[int, int, int, int]) -> float:
    lx, ly, lw, lh = left
    rx, ry, rw, rh = right
    x1, y1 = max(lx, rx), max(ly, ry)
    x2, y2 = min(lx + lw, rx + rw), min(ly + lh, ry + rh)
    intersection = max(0, x2 - x1) * max(0, y2 - y1)
    union = lw * lh + rw * rh - intersection
    return intersection / union if union else 0.0


@dataclass
class Candidate:
    id: int
    bbox: tuple[int, int, int, int]
    anchor_bbox: tuple[int, int, int, int]
    first_seen: float
    last_seen: float
    alerted: bool = False

    def age(self, now: float) -> float:
        return max(0.0, now - self.first_seen)


class StationaryTracker:
    def __init__(self, config: DetectionConfig):
        self.config = config
        self.candidates: list[Candidate] = []
        self._next_id = 1

    def reset(self) -> None:
        self.candidates.clear()

    def update(self, detections: list[Detection], timestamp: float) -> list[Candidate]:
        for candidate in self.candidates[:]:
            if timestamp - candidate.last_seen > self.config.max_gap_seconds:
                self.candidates.remove(candidate)

        unmatched = set(range(len(detections)))
        # Greedy matching is sufficient because candidates represent sparse stationary regions.
        for candidate in self.candidates[:]:
            choices = []
            for index in unmatched:
                box = detections[index].bbox
                if _distance(candidate.bbox, box) <= self.config.max_centroid_distance_px or _iou(candidate.bbox, box) >= self.config.match_iou:
                    choices.append((_distance(candidate.bbox, box), index))
            if not choices:
                continue
            _, index = min(choices)
            box = detections[index].bbox
            unmatched.remove(index)
            # A moving object starts a new candidate instead of inheriting its dwell time.
            if _distance(candidate.anchor_bbox, box) > self.config.max_centroid_distance_px:
                self.candidates.remove(candidate)
                unmatched.add(index)
                continue
            candidate.bbox = box
            candidate.last_seen = timestamp

        for index in unmatched:
            box = detections[index].bbox
            self.candidates.append(Candidate(self._next_id, box, box, timestamp, timestamp))
            self._next_id += 1

        alerts: list[Candidate] = []
        for candidate in self.candidates:
            if not candidate.alerted and candidate.age(timestamp) >= self.config.stationary_seconds:
                candidate.alerted = True
                alerts.append(candidate)
        return alerts
