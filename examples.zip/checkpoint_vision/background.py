from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from checkpoint_vision.config import BackgroundConfig, DetectionConfig


@dataclass(frozen=True)
class Detection:
    bbox: tuple[int, int, int, int]
    area: float


class AdaptiveBackground:
    def __init__(self, background: np.ndarray, config: BackgroundConfig):
        self.model = background.astype(np.float32)
        self.config = config

    def foreground(self, frame: np.ndarray, roi: np.ndarray, detection: DetectionConfig) -> np.ndarray:
        if frame.shape[:2] != self.model.shape[:2]:
            raise ValueError("Frame dimensions differ from the calibrated background. Recalibrate the background.")
        background = self.model.astype(np.uint8)
        roi_pixels = roi > 0
        bg_gray = cv2.cvtColor(background, cv2.COLOR_BGR2GRAY)
        frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        reference = float(np.mean(bg_gray[roi_pixels])) if np.any(roi_pixels) else 1.0
        current = float(np.mean(frame_gray[roi_pixels])) if np.any(roi_pixels) else 1.0
        scale = np.clip(reference / max(current, 1.0), 0.7, 1.3)
        normalized = cv2.convertScaleAbs(frame, alpha=float(scale))
        difference = cv2.absdiff(normalized, background)
        difference = cv2.cvtColor(difference, cv2.COLOR_BGR2GRAY)
        _, mask = cv2.threshold(difference, self.config.difference_threshold, 255, cv2.THRESH_BINARY)
        mask = cv2.bitwise_and(mask, roi)
        kernel_size = max(3, detection.morphology_kernel | 1)
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)
        # Pixels marked foreground are intentionally excluded from adaptation.
        background_pixels = cv2.bitwise_not(mask)
        cv2.accumulateWeighted(normalized, self.model, self.config.adaptation_rate, mask=background_pixels)
        return mask


def detections_from_mask(mask: np.ndarray, config: DetectionConfig) -> list[Detection]:
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    detections: list[Detection] = []
    for contour in contours:
        area = cv2.contourArea(contour)
        if not config.min_area_px <= area <= config.max_area_px:
            continue
        x, y, width, height = cv2.boundingRect(contour)
        detections.append(Detection((x, y, width, height), area))
    return detections
