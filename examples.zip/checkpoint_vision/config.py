from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class ROIConfig:
    points: list[list[int]] = field(default_factory=list)


@dataclass
class BackgroundConfig:
    path: str = "calibration/background.png"
    calibration_seconds: int = 30
    min_clean_frames: int = 30
    max_motion_fraction: float = 0.01
    motion_threshold: int = 24
    difference_threshold: int = 32
    adaptation_rate: float = 0.002


@dataclass
class DetectionConfig:
    min_area_px: int = 600
    max_area_px: int = 200_000
    morphology_kernel: int = 5
    stationary_seconds: float = 60.0
    max_gap_seconds: float = 3.0
    match_iou: float = 0.2
    max_centroid_distance_px: float = 50.0


@dataclass
class EventConfig:
    directory: str = "events"
    pre_seconds: float = 10.0
    post_seconds: float = 20.0
    codec: str = "mp4v"


@dataclass
class RuntimeConfig:
    reconnect_delay_seconds: float = 3.0
    resize_width: int | None = None


@dataclass
class AppConfig:
    source: str = ""
    roi: ROIConfig = field(default_factory=ROIConfig)
    background: BackgroundConfig = field(default_factory=BackgroundConfig)
    detection: DetectionConfig = field(default_factory=DetectionConfig)
    events: EventConfig = field(default_factory=EventConfig)
    runtime: RuntimeConfig = field(default_factory=RuntimeConfig)
    config_path: Path | None = field(default=None, repr=False, compare=False)

    def resolve(self, value: str) -> Path:
        path = Path(value)
        return path if path.is_absolute() else self.config_path.parent / path  # type: ignore[union-attr]

    @property
    def background_path(self) -> Path:
        return self.resolve(self.background.path)

    @property
    def events_path(self) -> Path:
        return self.resolve(self.events.directory)

    @property
    def resolved_source(self) -> str:
        """Return a local source path relative to YAML, preserving stream URLs."""
        if self.source.lower().startswith(("rtsp://", "rtsps://", "http://", "https://")):
            return self.source
        return str(self.resolve(self.source))


def _section(data: dict[str, Any], name: str, cls: type[Any]) -> Any:
    value = data.get(name, {}) or {}
    if not isinstance(value, dict):
        raise ValueError(f"Section '{name}' must be a mapping.")
    return cls(**value)


def load_config(path: str | Path) -> AppConfig:
    config_path = Path(path).resolve()
    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")
    with config_path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    if not isinstance(data, dict):
        raise ValueError("The configuration root must be a mapping.")
    config = AppConfig(
        source=str(data.get("source", "")),
        roi=_section(data, "roi", ROIConfig),
        background=_section(data, "background", BackgroundConfig),
        detection=_section(data, "detection", DetectionConfig),
        events=_section(data, "events", EventConfig),
        runtime=_section(data, "runtime", RuntimeConfig),
        config_path=config_path,
    )
    return config


def save_config(config: AppConfig) -> None:
    if config.config_path is None:
        raise ValueError("config_path is not set")
    output = asdict(config)
    output.pop("config_path", None)
    with config.config_path.open("w", encoding="utf-8") as handle:
        yaml.safe_dump(output, handle, allow_unicode=True, sort_keys=False)


def ensure_runtime_ready(config: AppConfig) -> None:
    if not config.source:
        raise ValueError("Set 'source' in the configuration or pass --source.")
    if len(config.roi.points) < 3:
        raise ValueError("ROI is not configured. Run calibrate-roi first.")
    if not config.background_path.exists():
        raise ValueError(
            f"Background image is missing: {config.background_path}. "
            "Run calibrate-background first."
        )
