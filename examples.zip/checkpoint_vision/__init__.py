"""Background-subtraction MVP for unattended-object alerts."""

__version__ = "0.1.0"
