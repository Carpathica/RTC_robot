from __future__ import annotations

from typing import Protocol

import numpy as np


class ObjectVerifier(Protocol):
    """Extension point for an optional YOLO-based candidate confirmation step."""

    def verify(self, frame: np.ndarray, bbox: tuple[int, int, int, int]) -> bool:
        """Return True when the candidate is an alert-worthy object."""


class AcceptAllVerifier:
    """MVP verifier: background candidates are forwarded without classification."""

    def verify(self, frame: np.ndarray, bbox: tuple[int, int, int, int]) -> bool:
        return True
