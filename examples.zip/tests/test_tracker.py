from checkpoint_vision.background import Detection
from checkpoint_vision.config import DetectionConfig
from checkpoint_vision.tracker import StationaryTracker


def config() -> DetectionConfig:
    return DetectionConfig(stationary_seconds=60, max_gap_seconds=3, max_centroid_distance_px=15, min_area_px=1)


def test_stationary_object_alerts_after_delay_once() -> None:
    tracker = StationaryTracker(config())
    detection = Detection((10, 10, 20, 20), 400)
    for second in range(60):
        assert not tracker.update([detection], second)
    alerts = tracker.update([detection], 60)
    assert len(alerts) == 1
    assert not tracker.update([detection], 61)


def test_walking_object_does_not_inherit_dwell_time() -> None:
    tracker = StationaryTracker(config())
    for second in range(0, 70, 5):
        assert not tracker.update([Detection((second * 10, 10, 20, 20), 400)], second)


def test_short_stop_has_no_alert() -> None:
    tracker = StationaryTracker(config())
    detection = Detection((10, 10, 20, 20), 400)
    for second in range(30):
        assert not tracker.update([detection], second)


def test_short_occlusion_preserves_candidate() -> None:
    tracker = StationaryTracker(config())
    detection = Detection((10, 10, 20, 20), 400)
    tracker.update([detection], 0)
    tracker.update([], 2)
    assert not tracker.update([detection], 3)
    for second in range(4, 60):
        assert not tracker.update([detection], second)
    alerts = tracker.update([detection], 60)
    assert len(alerts) == 1
