from pathlib import Path

import cv2
import numpy as np

from checkpoint_vision.cli import run
from checkpoint_vision.config import (
    AppConfig,
    BackgroundConfig,
    DetectionConfig,
    EventConfig,
    ROIConfig,
    RuntimeConfig,
)


def test_pipeline_writes_one_event_for_persistent_object(tmp_path: Path) -> None:
    video_path = tmp_path / "input.mp4"
    background_path = tmp_path / "background.png"
    writer = cv2.VideoWriter(str(video_path), cv2.VideoWriter_fourcc(*"mp4v"), 10, (100, 100))
    assert writer.isOpened()
    for frame_number in range(90):
        frame = np.zeros((100, 100, 3), dtype=np.uint8)
        if frame_number >= 10:
            cv2.rectangle(frame, (35, 35), (65, 65), (255, 255, 255), -1)
        writer.write(frame)
    writer.release()
    assert cv2.imwrite(str(background_path), np.zeros((100, 100, 3), dtype=np.uint8))

    config = AppConfig(
        source=str(video_path),
        roi=ROIConfig([[0, 0], [99, 0], [99, 99], [0, 99]]),
        background=BackgroundConfig(path=str(background_path), difference_threshold=20, adaptation_rate=0.001),
        detection=DetectionConfig(
            min_area_px=50,
            max_area_px=5_000,
            morphology_kernel=3,
            stationary_seconds=1,
            max_gap_seconds=1,
            max_centroid_distance_px=10,
        ),
        events=EventConfig(directory=str(tmp_path / "events"), pre_seconds=1, post_seconds=1),
        runtime=RuntimeConfig(),
        config_path=tmp_path / "config.yaml",
    )

    run(config, display=False)

    event_directories = list((tmp_path / "events").iterdir())
    assert len(event_directories) == 1
    assert (event_directories[0] / "event.json").exists()
    assert (event_directories[0] / "alert.jpg").exists()
    assert (event_directories[0] / "clip.mp4").exists()
