import cv2
import numpy as np

from checkpoint_vision.background import AdaptiveBackground, detections_from_mask
from checkpoint_vision.config import BackgroundConfig, DetectionConfig


def test_foreground_object_becomes_detection() -> None:
    base = np.zeros((100, 100, 3), dtype=np.uint8)
    frame = base.copy()
    cv2.rectangle(frame, (30, 30), (60, 60), (255, 255, 255), -1)
    roi = np.full((100, 100), 255, dtype=np.uint8)
    background = AdaptiveBackground(base, BackgroundConfig(difference_threshold=20, adaptation_rate=0.001))
    mask = background.foreground(frame, roi, DetectionConfig(min_area_px=100, max_area_px=5000, morphology_kernel=3))
    found = detections_from_mask(mask, DetectionConfig(min_area_px=100, max_area_px=5000, morphology_kernel=3))
    assert len(found) == 1
    assert found[0].bbox[0] <= 30 <= found[0].bbox[0] + found[0].bbox[2]
