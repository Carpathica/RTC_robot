import numpy as np

from checkpoint_vision.calibration import median_background, roi_mask, select_clean_frames


def test_motion_frames_are_excluded_from_background_calibration() -> None:
    base = np.full((40, 40, 3), 100, dtype=np.uint8)
    moving = base.copy()
    moving[10:30, 10:30] = 255
    mask = roi_mask(base.shape, [[0, 0], [39, 0], [39, 39], [0, 39]])
    clean = select_clean_frames([base, moving, base], mask, motion_threshold=20, max_motion_fraction=0.05)
    assert len(clean) == 1
    assert np.array_equal(median_background(clean), base)
